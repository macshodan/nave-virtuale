/*
 * verifica.js — pannello di verifica delle tappe.
 * Non serve leggerlo né modificarlo: in fondo alla pagina mostra
 *   1. che cosa avete già completato della tappa
 *   2. gli errori JavaScript, spiegati in italiano
 *   3. le richieste fatte al server della Nave virtuale
 */
(function () {
  'use strict';
  var tappa = document.currentScript ? document.currentScript.getAttribute('data-tappa') : '?';
  var errori = [], richieste = [], pannello = null, completata = false;

  // ── Cattura gli errori, anche quelli del vostro script (che viene caricato dopo questo)
  window.addEventListener('error', function (e) {
    if (!e.message) return;
    errori.push({ msg: e.message, riga: e.lineno || null });
    disegna();
  });
  window.addEventListener('unhandledrejection', function (e) {
    var r = e.reason;
    errori.push({ msg: (r && r.message) ? r.message : String(r), riga: null, async: true });
    disegna();
  });

  // ── Si aggancia alla Nave virtuale appena nave.js viene caricato
  var nave;
  try {
    Object.defineProperty(window, 'Nave', {
      configurable: true,
      get: function () { return nave; },
      set: function (v) {
        nave = v;
        try { v.onRichiesta(function (r) { richieste.push(r); disegna(); }); } catch (e) {}
      }
    });
  } catch (e) {}

  function testo(sel) { var el = document.querySelector(sel); return el ? el.textContent.trim() : null; }
  function voci(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); }
  function fatta(metodo, percorso, status) {
    return richieste.filter(function (r) { return r.metodo === metodo && r.path.split('?')[0].replace(/\/$/, '') === percorso && r.status === status; }).length;
  }
  function conClasseStato() {
    var li = voci('#lista li');
    return li.length > 0 && li.every(function (x) { return ['OK', 'AVVISO', 'CRITICO', 'DISATTIVO'].some(function (c) { return x.classList.contains(c); }); });
  }

  var CONTROLLI = {
    '1': function () {
      var eta = parseInt(testo('#eta'), 10);
      return [
        ['Nella pagina c\'è il nome della nave (#nome)', testo('#nome') === 'Nave Azzurra'],
        ['Nella pagina c\'è il porto di registro (#porto)', testo('#porto') === 'Livorno'],
        ['Nella pagina c\'è l\'età della nave, calcolata (#eta)', eta === 17]
      ];
    },
    '2': function () {
      var li = voci('#lista li');
      var primo = li[0] ? li[0].textContent : '';
      return [
        ['Nella pagina c\'è il numero di sensori (#totale)', testo('#totale') === '12'],
        ['La lista ha un elemento per ogni sensore', li.length === 12],
        ['Ogni elemento mostra nome, valore e unità di misura', /Cella 1/.test(primo) && /13[.,]09/.test(primo) && /V/.test(primo)],
        ['Sfida: ogni elemento ha la classe del suo stato (colori)', conClasseStato()]
      ];
    },
    '3': function () {
      return [
        ['Login riuscito: POST /auth/login → 200', fatta('POST', '/auth/login', 200) > 0],
        ['Richiesta con il token: GET /ships → 200', fatta('GET', '/ships', 200) > 0],
        ['Nella pagina c\'è il nome della nave ricevuto dal server (#nome)', testo('#nome') === 'Nave Azzurra' && fatta('GET', '/ships', 200) > 0],
        ['Nella pagina c\'è l\'operatore collegato (#operatore)', testo('#operatore') === 'Mario Rossi']
      ];
    },
    '4': function () {
      return [
        ['Richiesta GET /ships/NA00001/dashboard → 200', fatta('GET', '/ships/NA00001/dashboard', 200) > 0],
        ['La lista ha un elemento per ogni sensore, con i dati del server', voci('#lista li').length === 12 && fatta('GET', '/ships/NA00001/dashboard', 200) > 0],
        ['Ogni elemento ha la classe del suo stato (colori)', conClasseStato()],
        ['Sfida: la pagina si aggiorna da sola (almeno 2 richieste alla dashboard)', fatta('GET', '/ships/NA00001/dashboard', 200) >= 2]
      ];
    }
  };

  function spiega(m) {
    var r;
    if ((r = /^(?:Uncaught )?ReferenceError: (\S+) is not defined/.exec(m)) || (r = /^(\S+) is not defined/.exec(m)))
      return '«' + r[1] + '» non esiste. Controllate di averlo scritto esattamente come quando l\'avete dichiarato (maiuscole comprese), e che sia dichiarato con const o let prima di usarlo.';
    if (/Cannot set propert(y|ies) of null|null has no properties|can't access property .* is null/.test(m))
      return 'document.querySelector non ha trovato l\'elemento. Controllate l\'id: nel selettore ci vuole il cancelletto, ad esempio "#nome".';
    if ((r = /Cannot read propert(?:y|ies) of (undefined|null) \(reading '([^']+)'\)/.exec(m)))
      return 'State leggendo «.' + r[2] + '» da qualcosa che vale ' + r[1] + '. Stampate con console.log quello che c\'è prima del punto e guardate com\'è fatto davvero.';
    if (/await is only valid|await.*async/.test(m))
      return 'await si può usare solo dentro una funzione dichiarata async, ad esempio dentro async function avvia() { ... }.';
    if (/Assignment to constant variable|invalid assignment to const/.test(m))
      return 'State cambiando il valore di una const. Se il valore deve cambiare, dichiaratela con let.';
    if (/is not a function/.test(m))
      return 'State chiamando con le parentesi () qualcosa che non è una funzione. Controllate il nome (ad esempio querySelector, con la S maiuscola).';
    if (/Failed to fetch|NetworkError/.test(m))
      return 'La richiesta non è arrivata al server: la rete non è raggiungibile. Controllate l\'indirizzo, o il selettore della rete nella Nave virtuale.';
    if (/is not valid JSON|JSON\.parse|Unexpected end of JSON/.test(m))
      return 'La risposta non è JSON. Succede ad esempio con .json() su una risposta 204, che non ha body.';
    if (/Unexpected token|Unexpected identifier|Unexpected string|Unexpected number|missing \)|Unexpected end of input|Invalid or unexpected token|expected expression|unterminated/i.test(m))
      return 'Errore di scrittura: il browser non riesce a leggere il codice e non esegue niente. Cercate alla riga indicata (o in quella prima) parentesi non chiuse, virgole mancanti o virgolette sbagliate.';
    return 'Leggete il messaggio e la riga: di solito dicono già dov\'è il problema.';
  }

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function disegna() {
    if (!pannello) return;
    var lista = [];
    try { lista = (CONTROLLI[tappa] || function () { return []; })(); } catch (e) {}
    var tutte = lista.length && lista.every(function (c) { return c[1]; });
    var base = lista.length && lista.filter(function (c) { return !/^Sfida/.test(c[0]); }).every(function (c) { return c[1]; });
    if (base && !completata) { completata = new Date().toLocaleTimeString('it-IT'); }
    var h = '<h2>Verifica · tappa ' + esc(tappa) + '</h2>';
    var conSfida = lista.some(function (c) { return /^Sfida/.test(c[0]); });
    if (completata) h += '<p class="v-fatto">' + (tutte && conSfida ? 'Tappa completata, sfida compresa!' : 'Tappa completata!') + ' <span>(alle ' + completata + ')</span></p>';
    h += '<ul class="v-lista">' + lista.map(function (c) { return '<li class="' + (c[1] ? 'si' : 'no') + '">' + (c[1] ? '✓' : '○') + ' ' + esc(c[0]) + '</li>'; }).join('') + '</ul>';
    if (errori.length) {
      h += '<h2 style="margin-top:16px">Errori JavaScript</h2>' + errori.slice(-4).map(function (e) {
        return '<div class="v-errore"><code>' + esc(e.msg) + '</code>' + (e.riga ? ' <b>riga ' + e.riga + '</b>' : '') + '<br>' + esc(spiega(e.msg)) + '</div>';
      }).join('');
    }
    if (richieste.length) {
      h += '<h2 style="margin-top:16px">Richieste al server</h2><ul class="v-rich">' + richieste.slice(-8).reverse().map(function (r) {
        var cl = r.status >= 200 && r.status < 300 ? 'si' : 'no';
        var nota = r.status === 401 ? ' · manca il token, oppure è scaduto' : r.status === 415 ? ' · manca l\'header Content-Type' : r.status === 0 ? ' · rete assente' : '';
        return '<li><code>' + esc(r.metodo + ' ' + r.path) + '</code> → <b class="' + cl + '">' + (r.status || 'errore') + '</b> <span>' + r.ms + ' ms' + nota + '</span></li>';
      }).join('') + '</ul>';
    }
    pannello.innerHTML = h;
  }

  function monta() {
    var st = document.createElement('style');
    st.textContent = '#pannello-verifica{max-width:760px;margin:0 auto 40px;border:2px dashed #c6d3d7;border-radius:8px;padding:16px 20px;background:#fbfcfc;font-size:15px}' +
      '#pannello-verifica h2{font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:#566b77;margin:0 0 8px}' +
      '.v-lista,.v-rich{list-style:none;padding:0;margin:0;display:grid;gap:4px}.v-lista .si{color:#1d7a4c;font-weight:bold}.v-lista .no{color:#566b77}' +
      '.v-fatto{background:#dcefe4;color:#1d7a4c;font-weight:bold;padding:8px 12px;border-radius:6px;margin:0 0 10px}.v-fatto span{font-weight:normal}' +
      '.v-errore{background:#f6dddb;color:#7a1f1a;padding:8px 12px;border-radius:6px;margin-bottom:6px}.v-errore code{background:transparent;padding:0}' +
      '.v-rich b.si{color:#1d7a4c}.v-rich b.no{color:#b5302a}.v-rich span{color:#566b77;font-size:13px}';
    document.head.appendChild(st);
    pannello = document.createElement('section');
    pannello.id = 'pannello-verifica';
    document.body.appendChild(pannello);
    disegna();
    setInterval(disegna, 1000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', monta); else monta();
})();
